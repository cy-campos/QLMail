# QLMail
An Amazon Web Services (AWS) Lambda Layer Package for sending emails using the AWS Simple Email Service (SES)

The intention of this repo is to be able to add a common SES Email package as a layer to any AWS Lambda function that requires email functionality.
